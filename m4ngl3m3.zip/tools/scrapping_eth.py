#First, You need to locate in folder as "E:\resources\selenium resources\webdriver_manager-master" 
#Second, run python and insert following scripts

import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import winsound
import json
import random
from datetime import datetime
import csv
import random
import string
import names
import argparse
import os
import platform
import sys
from pathlib import Path
import numpy as np
from ultralytics import YOLO
import cv2

def random_delay():
    rt = random.randrange(0, 100) * 0.01
    return rt

def flattenDict(d, parent=None):
    ret = {}
    for k, v in d.items():
        if parent:
            k = f'{parent}.{k}'
        if isinstance(v, dict):
            ret.update(flattenDict(v, k))
        else:
            ret[k] = v
    return ret

# ------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------

chromeDir = 'C:\\Users\\1-RHU\\.wdm\\drivers\\chromedriver\\win64\\132.0.6834.84\\chromedriver.exe'
print("Start Bot.....")
addrs = []

##try:
f = open('f:\\test\\ak_20241021-202906_meta.txt', 'r')
data = f.read()
objs = data.split('\n')
jobjs = json.loads(objs[1])
##Words = jobjs[0]['data']['mnemonic'].split(' ')
f.close()
##except:
##    print('No address file has been found.')
##    exit(0)
    

options = uc.ChromeOptions()
prefs = {"credentials_enable_service": False,
         "profile.password_manager_enabled": False}
options.add_experimental_option("prefs", prefs)
driver = uc.Chrome(executable_path = chromeDir, options=options)

driver.maximize_window()

jobjNum = len(jobjs)

count = 0
for jobj in jobjs:
    count = count + 1
    if 'HD Key Tree' in jobj['type']:
        driver.get("https://www.myetherwallet.com/wallet/access/software?type=mnemonic")
        while(1):
            try:
                els = driver.find_elements(By.TAG_NAME, 'input')
            except:
                time.sleep(1+random_delay())
                

            if len(els) > 10:
                break

        time.sleep(3+random_delay())
        Words = jobj['data']['mnemonic'].split(' ')
        LenWords = len(Words)
        if LenWords == 12:
            i = 0
            for word in Words:
                element = els[4 + i]
                i = i + 1
                element.click()
                time.sleep(1+random_delay())
                element.send_keys(word)

        time.sleep(random_delay())
        btns = driver.find_elements(By.TAG_NAME, 'button')
        for btn in btns:
            if btn.text == 'Next':
                btn.click()
                break
    elif 'Simple Key Pair' in jobj['type']:
        driver.get("https://www.myetherwallet.com/wallet/access/software?type=private-key")
        while(1):
            try:
                els = driver.find_elements(By.TAG_NAME, 'input')
            except:
                time.sleep(1+random_delay())
                

            if len(els) > 3:
                break

        time.sleep(3+random_delay())
        els[2].click()
        els[2].send_keys(jobj['data'])


        
    print(str(count) + '/' + str(jobjNum))
    input("Press Enter to continue...")
