import json
import base64
from typing import Dict
from termcolor import colored
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Hash import SHA512
from Crypto.Protocol.KDF import PBKDF2
import json
from datetime import datetime
from itertools import product

##charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*'
charset = '0123456789'
charlist = list(charset)
charsLen = len(charset)
passlen = 8


def key_from_password(password: str, salt: str, iteration: int):
    password_bytes = password.encode("utf-8")
    salt_bytes = base64.b64decode(salt)


    key = PBKDF2(
        password_bytes,
        salt_bytes,
        dkLen=32,
        count=iteration,
        hmac_hash_module=SHA256)
        
    return key

filename = 'F:\\hashcat\\MAC_data\\3_old_data\\vault.json'
##filename = 'F:\\hashcat\\MAC_data\\symai-dev\\symai.json'
##filename = 'F:\\hashcat\\MAC_data\\Gregorys-MacBook-Air.local\\vault_0_0.json'
##filename = 'F:\\hashcat\\MAC_data\\tm_ldb\\meta_vault.json'
##filename = 'F:\\hashcat\\MAC_data\\developersstudios_cracked\\vault.json'
##password = 'ayeshabae'
filename = 'D:\\DOSGAMES\\reference\\DESKTOP-F5PT18M\\vault.json'
password = '12131415'

f = open(filename, 'r')
payload = json.load(f)
f.close()

print(filename)
print(charset)
print('password length = ' + str(passlen))
print(payload.keys())

salt = payload["salt"]
cracked = False

password = []
num = 0
for candidate in product(charset, repeat=passlen):
    password = ''.join(candidate)
##    print(password)
    key = key_from_password(password, salt, 10000)

    data = base64.b64decode(payload["data"])
    iv = base64.b64decode(payload["iv"])
    data_ = data[0:len(data)-len(iv)]


    cipher = AES.new(key, mode=AES.MODE_GCM, nonce=iv)
    decrypted_bytes = cipher.decrypt(data_)
    checkStr = base64.b64encode(decrypted_bytes)

    try:
        decrypted_text = decrypted_bytes.decode()
    except:
        ##print('failed.')
        continue
    else:
        cracked = True
        print(decrypted_text)
        break
    

if cracked:
    print('cracked!!!')
##    decrypted = json.loads(decrypted_text)
    current_datetime = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"ak_{current_datetime}.txt"
    with open(filename, "a") as file:
        file.write(decrypted_text)

else:
    print('no match.')
