#First, You need to locate in folder as "E:\resources\selenium resources\webdriver_manager-master" 
#Second, run python and insert following scripts

import time
import undetected_chromedriver as uc
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
import winsound
import json
import random
from datetime import datetime
import csv
import random
import string
import names
import argparse
import os
import platform
import sys
from pathlib import Path
import numpy as np
from ultralytics import YOLO
import cv2

def random_delay():
    rt = random.randrange(0, 100) * 0.01
    return rt

# ------------------------------------------------------------------------------------
# ------------------------------------------------------------------------------------

chromeDir = 'C:\\Users\\1-RHU\\.wdm\\drivers\\chromedriver\\win64\\132.0.6834.84\\chromedriver.exe'
print("Start Bot.....")
addrs = []

##try:
##    f = open('addresses.txt', 'r')
##    data = f.read()
##    addrs = data.split('\n')
##except:
##    print('No address file has been found.')
##    exit(0)
    
## vini
addrs.append('0xF06B978C8183eD3E002b4a8911123633547F0029')
addrs.append('0xf699429C2cf2DD712bC1D8812FBA5b833e5Db51c')
addrs.append('0xcD2a7fcD41550790da86EE74e0E429f94c960ad4')
addrs.append('0x88946D568871EC31d753034b3Bc486fBF60E4F2c')
addrs.append('0x38EE1B808d0285Dfe3dd76a2429b2e00963A43ba')
addrs.append('0x31B7aa3D44D9fafB4Ac7cE3bF7E1b01B39390Bc7')
addrs.append('0x20585D4aAF8527536359d6959C9fC9d93a6401e5')
addrs.append('0x0B13397388a105EFffD08F105dCd1826f6459099')


## Berkeleys
##addrs.append('0xF17eF8931396c9E12F6b6330629Af897c57E0099')
##addrs.append('0xE9C7bD070febb5771dAc09B5c24EEAC153CeBC28')
##addrs.append('0xdf08E06C8f977342c396Ab9c11339948434f8A22')
##addrs.append('0xC228A744065ac263D4e0791BcA01275B08443eC0')
##addrs.append('0x9802D77b482FB71601a68006DAbE4b1584a90f33')
##addrs.append('0x4B6AFBA485f5c30B38145b90913BC70017d11A4e')
##addrs.append('0x3ED86f52c819dc5D810398d2fE68976901eD1248')
##addrs.append('0x3b9d4ea13d54694833A1b087046C73582b414B96')
##addrs.append('0x0D67fA0c396D709DB88f54003D2663b558F64565')
##addrs.append('0x5162154208a209f67F97b2Da409cc855bb67f4CB')

## Sibs
##addrs.append('0xd000D16f48B9cA41b316CA7A94b85A2f7a0E6961')
##addrs.append('0x528B2fb4c91e27de57aEC86Bc505Dde0d0B434e6') 
##addrs.append('0x2a5f554d08049a9A24BD52Ac26AB0996EdDB6A8E') 

## wassilygraf
##addrs.append('0x7a07C7dD3Fdc6AE0C38Fb52C5eb8e82bb2Bf12c7')
##addrs.append('0x06e0061a4EDCc227FDA8d5aF579F588794d63DB3')
##addrs.append('0x529104337F53cEC53e8d4d387cc4F28104bEf382')

## Aka
##addrs.append('0xb10f19Ba978c351DA298ff5b4807a64C5E0e51F4')
##addrs.append('0x6c5Df0949575FEAf58D7b22DbA3C27459e82C659')
##addrs.append('0x2A595aE260cFbB8DB15533BC0D574019cd736C20')
##addrs.append('0x133C776e96f430F2CE73Dc3e3EAb2D534E130C6C')
##addrs.append('0x0c1C9Cde0EF4560D747b8bc6529465Bd5993267d')

## Itai
##addrs.append('0x8f367B79Af47dbe7677dEb8B3Bc7980907f98d7a')
##addrs.append('0x63D5588126e4bDb23952A2291460219175372860')
##addrs.append('0x4083F05d4F3530f0d7a129839cE14f8E47f6BE56')

## Amits
##addrs.append('0xE3707b1c6b224CD699dE4CDEADe24C911DBdd5B2')
##addrs.append('0xDe8BEdF9FEad21687Dd4376842b8B88EaBd8BFfE')
##addrs.append('0xDC9b8F89e6107F18843C8F24Dc518014a9b48C5d')
##addrs.append('0xC1Dd697460a12f33D10D75f68304A91Ffc2de928')
##addrs.append('0xC0B593cdAD6796287fF18391f143c887D79128Ba')
##addrs.append('0xa84b7a74b353000cfE1a037Cc74a6e8aE18ecC50')
##addrs.append('0xa736134222aB9d41c94d5C7B7Ea2C00AA4AE7d9A')
##addrs.append('0xa5ec2BDaC6941c0c72573Aa73cBC30c5Bb76DF28')
##addrs.append('0xA565Cd734522952CcFe6448aBD1575F838680834')
##addrs.append('0x953f0E08956087c0BfcC0deF9068521356Eb3b5E')
##addrs.append('0x7e1d0c504E49F1f29bEaD5cCeAB7c105CABfcdd6')
##addrs.append('0x6a466CD4735525E6454dBB12196D5A9b3D1DC9d5')
##addrs.append('0x6967F7e4a43623be714bb6e822Cb5FEDCbEeDcf3')
##addrs.append('0x5Ed9AD5CF6D95Cda113f885f82FEcf364B21CdE1')
##addrs.append('0x53932f85CDE0De4e9D32c4Abf928fEEf072255C8')
##addrs.append('0x504D92001efe772A661aEAB040CCfABE5a84Bc86')
##addrs.append('0x44806f269aC7dfC56D850aE729BA9DafE6E6D415')
##addrs.append('0x43B0aEA5807527b1E5EFc2Fe7304F5ba5E2F4E0c')
##addrs.append('0x431348818498e2331C17c0910D9A1aA66Ad9e6AF')
##addrs.append('0x3B346c6e83c108e954f7c29450072D2483D27152')
##addrs.append('0x11a32be32b4bb06a3F203A254D343C9d5F2eAb6A')
##addrs.append('0x0C47CbAbE0286FD0a3F40ef29d9ef18EaE66E18b')

## 5TM_HW
##addrs.append('0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266')
##addrs.append('0xBBe2ded2c9E0C8B6f0D36ab8e533509f98Ce05aF')
##addrs.append('0xB8A573139b95296AABdC4556415D121da358149d')
##addrs.append('0x7C03A3238C4A53bC87673e093Ffc0185866909Dd')
##addrs.append('0x4DDae7D3694984BDa9E4BDA1c47145868396884D')

## Denis
##addrs.append('0xdCCa288d0e5EC0155a45EB32784A8Be4e5d4EE28')
##addrs.append('0x36BF5C2248eb9c7D52E657Ac759D977ac04919C0')
##addrs.append('0x1e7Ca6983a6221A7DD48f09Fd888e0D5380699D2')
##addrs.append('0x10cF9E6bdB737C7d900ad0eA827683E822BBEa7A')

## Algokk
##addrs.append('0xB9EC379A16FC0eaa9659eAb2CC8cE5f0e793a294')

## 5TM_noname5-HTH
##addrs.append('0x59D3b3B2EC3013C1DF0dBac922aE1767445a7Cd1')

## DESKTOP-30MLL02
##addrs.append('0xc11d42bfbA90c08466080C2d34357900162F9D02')

## Dido
##addrs.append('0x0F68Ef73422a369EbEB59840830bcA7Bdb47b390')

## 8_BBOOK-PRO 143516
##addrs.append('0xfE6f618E95fA3C4b2474EC7d6d40137D57214fcF')
##addrs.append('0xfdA3E4De607fae48B5cC41331a65278465bfa18f')
##addrs.append('0xFC583cc354bce63130a83354CF4774FF4e61E36a')
##addrs.append('0xcF84676C1E89895A612266F5968114F2F5Db3Dd7')
##addrs.append('0xa08C7CDA8015280b32452647Fe66e19746b23D59')
##addrs.append('0x8EBb45cae5a89733184547174266E0Eb9F057C51')
##addrs.append('0x5F185Da55f7BBD9217E3b3CeE06b180721FA6d34')
##addrs.append('0x5e34F77f8222a55C0d4cD646Dd1EfE8a22D6766b')
##addrs.append('0x4E3D58915131b64818D6eC9E269119F9e20FFaE0')
##addrs.append('0x0849b665B10Ab5dC5e5A5f7bDE6C1B2924f86C63')

## PRW
##addrs.append('0xFbF2bBd1E0E16932Ca61B0ca0854B97b6cb93BB2')
##addrs.append('0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266')
##addrs.append('0xEA535e071A99D6766777763bF538267079CC8Ec0')
##addrs.append('0xD869249FC994D74A7639bCe6E48ecDF1D79cEc92')
##addrs.append('0xd493160B0915D55c86d742115CF48A56eB02B557')
##addrs.append('0xC9b67072Ef14d9dA86d1370D73BC70c1d1ABbDdc')
##addrs.append('0x8eb6B1a19236C96cCe95Fa44E6F0d24d3739Ed82')
##addrs.append('0x8480Da42a7A792D3A84117C6dd6Dae3FdA9d8CD5')
##addrs.append('0x70997970C51812dc3A010C7d01b50e0d17dc79C8')
##addrs.append('0x3C44CdDdB6a900fa2b585dd299e03d12FA4293BC')
##addrs.append('0x320022859ce2a7A4ebd6C23815f7A1d16c63290d')
##addrs.append('0x27a4fD4B25f42F3955444EF5a9600A1dcD285f1F')
##addrs.append('0x22b00fDf306155818B085571d0927b7cd417eF69')
##addrs.append('0x1c9EB1Db436EBE1ee4da60458DF14A427CB1A161')
##addrs.append('0x074346Bb8d43f7A332E5Ba61B10D83Fc0eF7feE9')
##addrs.append('0x03aEe4Fc54b7a90820bBf4dEc973a556520Df782')

## LAPTOP_CNLE
##addrs.append('0xe01b21d6d5f6c7940f637686e5d954f17735c839')
##addrs.append('0xbff289ed0568e4c6cee024733558254669e66770')
##addrs.append('0x2239da81160cb6019d74446f7cf436d67c00e2d8')
##addrs.append('0x20ded412a71ef5b5a4db3e4204df63b7c05cd251')
##addrs.append('0x20ab8f3884804c8e8659aaef77bd389ebd54273e')
##addrs.append('0x1eb5be8e8d2c5c4d523f7240b2bdd79c8b1e64e8')


options = uc.ChromeOptions()
prefs = {"credentials_enable_service": False,
         "profile.password_manager_enabled": False}
options.add_experimental_option("prefs", prefs)
driver = uc.Chrome(executable_path = chromeDir, options=options)

driver.maximize_window()
driver.get("https://debank.com")

while(1):
    try:
        els = driver.find_elements(By.TAG_NAME, 'input')
    except:
        time.sleep(1+random_delay())
        

    if len(els) > 0:
        break

time.sleep(3+random_delay())
element = els[0]
balList = []
for addr in addrs:
    element.send_keys(addr)
    time.sleep(2+random_delay())
    element.send_keys(Keys.ENTER)
    time.sleep(5+random_delay())
    
    els = driver.find_elements(By.TAG_NAME, 'input')
    element = els[1]
    time.sleep(2+random_delay())
    classels = driver.find_elements(By.XPATH, '//*[contains(@class,"totalAsset")]')
    balTxt = classels[0].text
    txtLen = len(balTxt)
    balText = balTxt.replace(',','')
    endIdx = balText.find('\n')
    if endIdx > 0 and endIdx < txtLen:
        balText = balText[1:endIdx]
    else:
        balText = balText[1:txtLen]
    balList.append(float(balText))
    print(float(balText))

driver.close()
finalStr = 'total = $' + str(sum(balList))
print(finalStr)












