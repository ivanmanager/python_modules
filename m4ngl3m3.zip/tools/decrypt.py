import json
import base64
from typing import Dict
from termcolor import colored
from Crypto.Cipher import AES
from Crypto.Hash import SHA256
from Crypto.Hash import SHA512
from Crypto.Protocol.KDF import PBKDF2
import json
from password_generator import PasswordGenerator
from datetime import datetime
from itertools import product

pwo = PasswordGenerator()
pwo.minschars = 1
##pwo.excludeschars = '~!@#$%^&*()_+-=[]{}\|/?.>,<'
pwo.excludeschars = '><[]{}\|^`~;'
pwo.minnumbers = 1
pwo.minlchars = 1
pwo.minuchars = 1
pwo.maxlen = 20
pwo.minlen = 20

def key_from_password(password: str, salt: str, iteration: int):
    password_bytes = password.encode("utf-8")
    salt_bytes = base64.b64decode(salt)


    key = PBKDF2(
        password_bytes,
        salt_bytes,
        dkLen=32,
        count=iteration,
        hmac_hash_module=SHA256)
        
    return key

##filename = 'F:\\hashcat\\MAC_data\\symai-dev\\vault.json'
##filename = 'F:\\hashcat\\MAC_data\\Gregorys-MacBook-Air.local\\vault_0_0.json'
##filename = 'F:\\hashcat\\MAC_data\\tm_ldb\\meta_vault.json'
##filename = 'F:\\hashcat\\MAC_data\\developersstudios_cracked\\vault.json'
##password = 'ayeshabae'
##filename = 'D:\\DOSGAMES\\reference\\DESKTOP-F5PT18M\\vault.json'
##filename = 'F:\\hashcat\\MAC_data\\2002\\vault.json'
filename = 'd:\\DOSGAMES\\MAC_data\\tm_ldb\\Philipps-MacBook-Air.local\\vault.json'

f = open(filename, 'r')
payload = json.load(f)
f.close()

print(filename)

print('password max length = ' + str(pwo.maxlen))
print('password min length = ' + str(pwo.minlen))
print(payload.keys())

salt = payload["salt"]
try:
    iterations = payload['keyMetadata']['params']['iterations']
except:
    iterations = 10000
    
cracked = False
charset1 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
charset2 = 'abcdefghijklmnopqrstuvwxyz'
charset3 = '@#!'
charset4 = '1234567890'

num = 0

while(1):
##    password = 'IndYux@_@99'
##    password = pwo.generate()
    password = pwo.shuffle_password('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890!@#$%^&*()+?', pwo.maxlen)
#    PrefixChar = pwo.shuffle_password('ABCDEFGHIJKLMNOPQRSTUVWXYZ',1)
##    password = pwo.shuffle_password('abcdefghijklmnopqrstuvwxyz', pwo.maxlen)
#    Randword = pwo.shuffle_password('abcdefghijklmnopqrstuvwxyz',3)
#    RandNum = pwo.shuffle_password('1234567890',5)
#    Symb = pwo.shuffle_password('@#!',1)
#    password = PrefixChar + Randword + Symb + RandNum
##    password = pwo.shuffle_password('abcdefghijklmnopqrstuvwxyz', pwo.maxlen)
##    password = pwo.non_duplicate_password(15)
##for candidate1 in product(charset1, repeat=1):
##    for candidate2 in product(charset2, repeat=5):
##        for candidate3 in product(charset3, repeat=1):
##            for candidate4 in product(charset4, repeat=4):
##                password = ''.join(candidate1 + candidate2 + candidate3 + candidate4)
##    
##    print(password)

    key = key_from_password(password, salt, iterations)

    data = base64.b64decode(payload["data"])
    iv = base64.b64decode(payload["iv"])
    data_ = data[0:len(data)-len(iv)]


    cipher = AES.new(key, mode=AES.MODE_GCM, nonce=iv)
    decrypted_bytes = cipher.decrypt(data_)
    checkStr = base64.b64encode(decrypted_bytes)

    try:
        decrypted_text = decrypted_bytes.decode()
    except:
##        print('failed.')
        continue
    else:
        cracked = True
        print(decrypted_text)
        break
    

##if cracked:
##    print('cracked!!!')
####    decrypted = json.loads(decrypted_text)
##    current_datetime = datetime.now().strftime("%Y%m%d-%H%M%S")
##    filename = f"ak_{current_datetime}.txt"
##    with open(filename, "a") as file:
##        file.write(decrypted_text)


if cracked:
    print('cracked!!!')
    decrypted = json.loads(decrypted_text)
    cendata = decrypted[0]['data']['mnemonic']
    mndata = ''
    for citem in cendata:
        mndata = mndata + chr(citem)

    decrypted[0]['data']['mnemonic'] = mndata
    current_datetime = datetime.now().strftime("%Y%m%d-%H%M%S")
    filename = f"ak_{current_datetime}.txt"
##    print(decrypted)
    with open(filename, "a") as file:
        file.write(json.dumps(decrypted))

else:
    print('not resolved.')
