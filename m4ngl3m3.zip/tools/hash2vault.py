import json

hashfilename = 'd:\\DOSGAMES\\MAC_data\\KKH\\rene-InfinityBook-Pro-15-v52\\hash.txt'
f = open(hashfilename, 'r')
data = f.read()
f.close()

lines = data.split('$')
while(1):
    try:
        lines.remove('')
    except:
        break

if 'metamask' in lines[0]:
    print('metamask hash has been detected.')
else:
    print('No metamask hash. bye!')
    exit(0)

is_600000 = False
vault = {}
if '600000' in lines[1]:
    is_600000 = True
    print('Iteration is 600000.')
    vault['data'] = lines[4]
    vault['iv'] = lines[3]
    vault['keyMetadata'] = {}
    vault['keyMetadata']['params'] = {}
    vault['keyMetadata']['params']['iterations'] = 600000
    vault['keyMetadata']['algorithm'] = 'PBKDF2'
    vault['salt'] = lines[2]    
else:
    print('normal iteration.')
    vault['data'] = lines[3]
    vault['iv'] = lines[2]
    vault['salt'] = lines[1]


    
    
f = open('f:\\vault_generated.json', 'w')
json.dump(vault, f)
f.close()
print('finished.')
