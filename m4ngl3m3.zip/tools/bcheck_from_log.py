from web3 import Web3
from mnemonic import Mnemonic
from eth_account import Account
import time
import sys
from datetime import datetime
import pyminizip
import os
import json

Account.enable_unaudited_hdwallet_features()
web3 = Web3(Web3.HTTPProvider('https://rpc.mevblocker.io'))

num = 1
print('loading log file...')
##logfilename = 'D:\\DOSGAMES\\MAC_data\\hhs\\5TM\\5TM-20250207-maxim\\0_0_nkbihfbeogaeaoehlefnkodbefgpgknn_358037.log'
##logfilename = 'D:\\DOSGAMES\\MAC_data\\KKH\\8_MacBook-Pro-de-Vinicius-Miguel-5.local-viniciusmigueloliveira1_bal_100000\\1727215039348\\0_6_nkbihfbeogaeaoehlefnkodbefgpgknn_057630.log'
##logfilename = 'D:\\DOSGAMES\\MAC_data\\JJJ\\6k-0x873c13\\0_0_nkbihfbeogaeaoehlefnkodbefgpgknn_010200.log'
logfilename = 'D:\\DOSGAMES\\MAC_data\\tm_ldb\\Christophers-MacBook-Pro.local\\1738156942\\86_1_0_nkbihfbeogaeaoehlefnkodbefgpgknn_1253457.log'
try:
    with open(logfilename, 'r', encoding='utf8') as f:
        data = f.read()
        print('urf-8 encoding has been detected.')
except:
    print('')

try:
    with open(logfilename, 'r', encoding='unicode_escape') as f:
        data = f.read()
        print('unicode_escape encoding has been detected.')
except:
    print('')

try:
    with open(logfilename, 'r', encoding='iso-8859-1') as f:
        data = f.read()
        print('iso-8859-1 encoding has been detected.')
except:
    print('')

try:
    with open(logfilename, 'r', encoding='ascii') as f:
        data = f.read()
        print('ascii encoding has been detected.')
except:
    print('')
    
f.close()
print('log file has been loaded successfully.')
startidx = data.find('identiti')
if startidx < 0:
    print('no address.')
    exit(0)
else:
    startidx = startidx + 12

endidx = 0
try:
    endidx = data.find('improvedTokenAllowanceEnabled') - 2
    print('improved token has been found.')
except:
    print('find next keyword...')

if endidx <= 0:
    try:
        endidx = data.find('incomingTransactionsPreferences') - 2
    except:
        print('log file has some problem.')
        exit(0)
try:
    endidx = data[startidx:].find('}}') + startidx + 2
except:
    print('log file has some problem.')
    exit(0)
    
addrdata = data[startidx:endidx]
print(addrdata)
try:
    jsondata = json.loads(addrdata,strict=False)
except:
    print('No address.')
    exit(0)
print('\n')
print('Start balance scanning...')
f = open('addresses.txt', 'w')
while(1):
    try:
        dataitem = jsondata.popitem()
    except:
        print('finished.')
        break
    
    address = dataitem[0]
    f.write(address)
    f.write('\n')
    # Get the balance of an Ethereum address
    try:
        checksum_address = web3.to_checksum_address(address)
    except:
        print(address + ' is invalid.')
        continue
    try:
        balance = web3.eth.get_balance(checksum_address)
    except:
        print(args[0] + ' is limit rate now.')
        time.sleep(0.1)
        continue

    # Convert the balance from Wei to Ether
    try:
        balance_in_ether = web3.from_wei(balance, 'ether')
    except:
        print(args[0] + ' is limit rate now.')
        time.sleep(0.1)
        continue
        
    # Print the balance
    print(f"{num}: {checksum_address}->{balance_in_ether}")
    num = num + 1
f.close()
